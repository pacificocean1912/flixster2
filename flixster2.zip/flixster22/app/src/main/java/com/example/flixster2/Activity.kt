package com.example.flixster2

import android.os.Bundle
import android.util.Log
import android.widget.RatingBar
import android.widget.TextView
import com.codepath.asynchttpclient.AsyncHttpClient
import com.codepath.asynchttpclient.callback.JsonHttpResponseHandler
import com.google.android.youtube.player.YouTubeBaseActivity;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerView;
import okhttp3.Headers

private const val KEY="AIzaSyB6gF1Fd8A00WWvhNetbwmdiENuO1AF_qY"
private const val Url="https://api.themoviedb.org/3/movie/%d/videos?api_key=a07e22bc18f5cb106bfe4cc1f83ad8ed"
class DetailActivity : YouTubeBaseActivity() {

    private lateinit var Title: TextView
    private lateinit var Overview: TextView
    private lateinit var ratings: RatingBar
    private lateinit var View: YouTubePlayerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity)
        Title = findViewById(R.id.Title)
        View = findViewById(R.id.player)
        Overview = findViewById(R.id.Overview)
        ratings = findViewById(R.id.Average)


        val movie = intent.getParcelableExtra<Movie>("MOVIE_EXTRA") as Movie
        Title.text = movie.title
        Overview.text = movie.overview
        ratings.rating = movie.voteAverage.toFloat()

        val client = AsyncHttpClient()
        client.get(Url.format(movie.movieId), object : JsonHttpResponseHandler() {
            override fun onFailure(
                statusCode: Int,
                headers: Headers?,
                response: String?,
                throwable: Throwable?
            ) {
                Log.e("activity", "onFailure $statusCode")
            }

            override fun onSuccess(statusCode: Int, headers: Headers?, json: JSON) {
                val results = json.jsonObject.getJSONArray("results")
                if (results.length() == 0) {
                    return
                }
                val movieTrailerJson = results.getJSONObject(0)
                val youtubeKey = movieTrailerJson.getString("key")
                //play video with this trailer
                initializeYoutube(youtubeKey)
            }

        })
    }

    private fun initializeYoutube(youtubeKey: String) {
        View.initialize(KEY, object : YouTubePlayer.OnInitializedListener {
            override fun onInitializationSuccess(
                provider: YouTubePlayer.Provider?,
                player: YouTubePlayer?,
                p2: Boolean
            ) {
                player?.cueVideo(youtubeKey);
            }

            override fun onInitializationFailure(
                p0: YouTubePlayer.Provider?,
                p1: YouTubeInitializationResult?
            ) {
                Log.i("activity", "onInitializationFailure")
            }

        })

    }
}