package com.example.flixster2

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class MovieAdapter(private val context: Context, private val movies: List<Movie>) : RecyclerView.Adapter<MovieAdapter.ViewHolder>()
{
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.items,parent,false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val movie = movies[position]
        holder.bind(movie)
    }

    override fun getItemCount() = movies.size


    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView), View.OnClickListener {

        private val Poster = itemView.findViewById<ImageView>(R.id.Poster)
        private val Title = itemView.findViewById<TextView>(R.id.Title)
        private val Overview = itemView.findViewById<TextView>(R.id.Overview)

        init{
            itemView.setOnClickListener(this)
        }
        fun bind(movie: Movie) {
            Title.text = movie.title
            Overview.text=movie.overview
            Glide.with(context).load(movie.posterImageUrl).into(Poster)
        }

        override fun onClick(p0: View?) {
            val movie = movies[adapterPosition]
            val intent = Intent(context,DetailActivity::class.java)
            intent.putExtra("MOVIE_EXTRA",movie)
            context.startActivity(intent)
        }
    }
}